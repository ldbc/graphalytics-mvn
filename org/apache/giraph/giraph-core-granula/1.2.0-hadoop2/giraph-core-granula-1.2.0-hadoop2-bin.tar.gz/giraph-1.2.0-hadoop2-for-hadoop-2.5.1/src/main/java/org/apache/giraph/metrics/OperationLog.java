/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.giraph.metrics;

import org.apache.log4j.Logger;

public class OperationLog {

	private static final Logger LOG = Logger.getLogger(OperationLog.class);

    public static void markStartSuperstep(long superstep) {
        LOG.info(String.format("time=%d, event=start, phase=Superstep, superstep=%d", System.currentTimeMillis(),
                superstep));
    }

    public static void markEndSuperstep(long superstep) {
        LOG.info(String.format("time=%d, event=end, phase=Superstep, superstep=%d", System.currentTimeMillis(),
                superstep));
    }

    public static void markStart(String phase) {
        LOG.info(String.format("time=%d, event=start, phase=%s", System.currentTimeMillis(), phase));
    }

	public static void markStart(String phase, int workerId) {
	    LOG.info(String.format("time=%d, event=start, phase=%s, worker=%d", System.currentTimeMillis(), phase,
                workerId));
	}

    public static void markStart(String phase, int workerId, long superstep) {
        LOG.info(String.format("time=%d, event=start, phase=%s, worker=%d, superstep=%d", System.currentTimeMillis(),
                phase, workerId, superstep));
    }

    public static void markStart(String phase, int workerId, long superstep, String thread) {
        LOG.info(String.format("time=%d, event=start, phase=%s, worker=%d, superstep=%d, thread=%s",
                System.currentTimeMillis(), phase, workerId, superstep, thread));
    }

    public static void markStart(String phase, int workerId, long superstep, String thread, int partition) {
        LOG.info(String.format("time=%d, event=start, phase=%s, worker=%d, superstep=%d, thread=%s, partition=%d",
                System.currentTimeMillis(), phase, workerId, superstep, thread, partition));
    }

    public static void markEnd(String phase) {
        LOG.info(String.format("time=%d, event=end, phase=%s", System.currentTimeMillis(), phase));
    }

    public static void markEnd(String phase, int workerId) {
        LOG.info(String.format("time=%d, event=end, phase=%s, worker=%d", System.currentTimeMillis(), phase,
                workerId));
    }

    public static void markEnd(String phase, int workerId, long superstep) {
        LOG.info(String.format("time=%d, event=end, phase=%s, worker=%d, superstep=%d", System.currentTimeMillis(),
                phase, workerId, superstep));
    }

    public static void markEnd(String phase, int workerId, long superstep, String thread) {
        LOG.info(String.format("time=%d, event=end, phase=%s, worker=%d, superstep=%d, thread=%s",
                System.currentTimeMillis(), phase, workerId, superstep, thread));
    }

    public static void markEnd(String phase, int workerId, long superstep, String thread, int partition) {
        LOG.info(String.format("time=%d, event=end, phase=%s, worker=%d, superstep=%d, thread=%s, partition=%d",
                System.currentTimeMillis(), phase, workerId, superstep, thread, partition));
    }

    public static void log(long timestamp, String message) {
	    LOG.info(String.format("time=%d, %s", timestamp, message));
    }

}

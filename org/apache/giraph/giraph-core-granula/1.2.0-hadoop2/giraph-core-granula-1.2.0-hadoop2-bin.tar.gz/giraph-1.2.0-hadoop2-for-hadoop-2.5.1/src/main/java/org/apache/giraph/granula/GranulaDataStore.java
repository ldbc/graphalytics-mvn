/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.giraph.granula;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Created by wing on 27-3-15.
 */
public class GranulaDataStore {

    public static String workerId;

    public static AtomicLong ContainersLoaded = new AtomicLong();

    public static AtomicLong SentMsgs = new AtomicLong();

    public static AtomicLong LoadedDataVolume = new AtomicLong();

    public static AtomicLong ActiveVertices = new AtomicLong();

    public static AtomicLong SentMsgVolume = new AtomicLong();
    public static AtomicLong RemoteMsgVolume = new AtomicLong();
    public static AtomicLong ReceivedMsgVolume = new AtomicLong();

    public static AtomicLong SentReqVolume = new AtomicLong();
    public static AtomicLong RemoteReqVolume = new AtomicLong();
    public static AtomicLong ReceivedReqsVolume = new AtomicLong();

    public static long SetupStartTime = Long.MAX_VALUE;
    public static long ZookeeperStartTime;
    public static long ZookeeperEndTime;
    public static long SetupEndTime = Long.MAX_VALUE;


    public static TimeSerieStore PartitionTimeSeries = new TimeSerieStore(2 * 1000); //30 * 1000
    public static TimeSerieStore ReceivedMsgVolumeTimeSeries = new TimeSerieStore(2 * 1000); //30 * 1000
    public static TimeSerieStore SentMsgVolumeTimeSeries = new TimeSerieStore(2 * 1000); //30 * 1000
}

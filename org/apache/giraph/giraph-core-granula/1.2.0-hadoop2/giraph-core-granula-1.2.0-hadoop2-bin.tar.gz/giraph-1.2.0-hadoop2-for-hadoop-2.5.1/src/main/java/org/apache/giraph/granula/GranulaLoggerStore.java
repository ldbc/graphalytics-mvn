/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.giraph.granula;

/**
 * Created by wing on 10-4-15.
 */
public class GranulaLoggerStore {

    public static GranulaLogger giraphJobLogger;
    public static GranulaLogger executeLogger;
    public static GranulaLogger setupLogger;
    public static GranulaLogger superstepLogger;
    public static GranulaLogger localSuperstepLogger;
    public static GranulaLogger processGraphLogger;
    public static GranulaLogger loadGraphLogger;
    public static GranulaLogger preApplicationLogger;

    public static GranulaLogger postApplicationLogger;
    public static GranulaLogger preComputeLogger;
    public static GranulaLogger computeLogger;
    public static GranulaLogger postComputeLogger;

    public static GranulaLogger computeThreadLogger;

    public static GranulaLogger vertexComputeLogger;

    public static GranulaLogger offloadPartitionLogger;

    public static void load() {
        giraphJobLogger = new GranulaLogger(GiraphTerm.Giraph, IdentifierType.Unique,
                GiraphTerm.Job, IdentifierType.Unique);

        executeLogger = new GranulaLogger(GiraphTerm.Giraph, IdentifierType.Unique,
                GiraphTerm.Execute, IdentifierType.Unique);

        setupLogger = new GranulaLogger(GiraphTerm.Giraph, IdentifierType.Unique,
                GiraphTerm.Setup, IdentifierType.Unique);

        loadGraphLogger = new GranulaLogger(GiraphTerm.Giraph, IdentifierType.Unique,
                GiraphTerm.LoadGraph, IdentifierType.Unique);

        processGraphLogger = new GranulaLogger(GiraphTerm.Giraph, IdentifierType.Unique,
                GiraphTerm.ProcessGraph, IdentifierType.Unique);

        superstepLogger = new GranulaLogger(GiraphTerm.Worker,  "M",
                GiraphTerm.Superstep, String.valueOf(Integer.MIN_VALUE));

        localSuperstepLogger = new GranulaLogger(GiraphTerm.Worker, String.valueOf(Integer.MIN_VALUE),
                GiraphTerm.LocalSuperstep, String.valueOf(Integer.MIN_VALUE));

        preComputeLogger = new GranulaLogger(GiraphTerm.Worker, String.valueOf(Integer.MIN_VALUE),
                GiraphTerm.PreCompute, String.valueOf(Integer.MIN_VALUE));

        postComputeLogger = new GranulaLogger(GiraphTerm.Worker, String.valueOf(Integer.MIN_VALUE),
                GiraphTerm.PostCompute, String.valueOf(Integer.MIN_VALUE));

        computeLogger = new GranulaLogger(GiraphTerm.Worker, String.valueOf(Integer.MIN_VALUE),
                GiraphTerm.Compute, String.valueOf(Integer.MIN_VALUE));

        offloadPartitionLogger = new GranulaLogger(GiraphTerm.Worker, IdentifierType.Unique,
                GiraphTerm.OffloadPartition, IdentifierType.Unique);

        preApplicationLogger = new GranulaLogger(GiraphTerm.Worker, IdentifierType.Unique,
                GiraphTerm.PreApplication, IdentifierType.Unique);

        postApplicationLogger = new GranulaLogger(GiraphTerm.Worker, IdentifierType.Unique,
                GiraphTerm.PostApplication, IdentifierType.Unique);

        computeThreadLogger = new GranulaLogger(GiraphTerm.WorkerThread, String.valueOf(Integer.MIN_VALUE),
                GiraphTerm.ParallelCompute, String.valueOf(Integer.MIN_VALUE));


        vertexComputeLogger = new GranulaLogger(GiraphTerm.WorkerThread, String.valueOf(Integer.MIN_VALUE),
                GiraphTerm.VertexCompute, String.valueOf(Integer.MIN_VALUE));

    }
}

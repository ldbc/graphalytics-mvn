/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.giraph.granula;

import java.util.ArrayList;
import java.util.List;

/**
 * Print log messages only if the time is met.  Thread-safe.
 */
public class TimeSerieStore {
  /** Last time printed */
  private volatile long lastPrint = System.currentTimeMillis();
  /** Minimum interval of time to wait before printing */
  private final int msecs;

  private List<TimeValue> timeValues;

  /**
   * Constructor of the timed logger
   *
   * @param msecs Msecs to wait before printing again
   */
  public TimeSerieStore(int msecs) {
    this.msecs = msecs;
    timeValues = new ArrayList<>();
  }

  /**
   * Print to the info log level if the minimum waiting time was reached.
   *
   */
  public void add(long value) {
    if (isAddable()) {
      timeValues.add(new TimeValue(value));
    }
  }

  public void empty() {
    timeValues = new ArrayList<>();
  }

  /**
   * Is the log message printable (minimum interval met)?
   *
   * @return True if the message is printable
   */
  public boolean isAddable() {
    if (System.currentTimeMillis() > lastPrint + msecs) {
      lastPrint = System.currentTimeMillis();
      return true;
    }

    return false;
  }

  public void forceadd(long value) {
    timeValues.add(new TimeValue(value));
  }

  public String export(){
    StringBuilder string = new StringBuilder();
    for (TimeValue timeValue : timeValues) {
      string.append(timeValue.toString() + "#");
    }
    return string.toString();
  }


  private class TimeValue {
    long timestamp;
    long value;

    public TimeValue(long value) {
      this.timestamp = System.currentTimeMillis();
      this.value = value;
    }

    @Override
    public String toString() {
      return timestamp + "-" + value;
    }
  }

}
